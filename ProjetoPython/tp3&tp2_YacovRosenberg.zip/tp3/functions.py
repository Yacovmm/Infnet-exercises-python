def isPositivo(a):
  if a >= 0:    
    return True
  else:
    return False

def isPar(a):
  if a % 2 == 0:    
    return True
  else:
    return False