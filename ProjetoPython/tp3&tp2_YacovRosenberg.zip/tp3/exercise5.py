a = int(input("Insira o primeiro númeor:"))
b = int(input("Insira o segundo númeor:"))

print("O primeiro número é maior que o segundo"  ) if(a > b) else print("O segundo número  é maior que o primeiro " ) 