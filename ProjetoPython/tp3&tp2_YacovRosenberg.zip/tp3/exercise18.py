lista = [3, 5, 1, 7, 2, 8, 11, -2, 3 -6, 0]
print('Original', lista)
print('Invertida', lista[::-1])