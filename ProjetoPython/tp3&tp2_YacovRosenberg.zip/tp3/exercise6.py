a = int(input("Insira o primeiro númeor:"))
b = int(input("Insira o segundo númeor:"))
c = int(input("Insira o terceiro númeor:"))


print(max(a,b,c))