lista = []

for i in range(1,6):
  a = int(input("Insira um número:"))
  lista.append(a)
  
b = sum(lista) / 5



print (b)
